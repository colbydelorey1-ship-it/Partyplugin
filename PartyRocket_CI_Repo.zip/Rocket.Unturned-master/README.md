We, Sven Mawby "fr34kyn01535" and Enes Sadık Özbek "Trojaner" stopped maintaining RocketMod. 

Read [our message](https://github.com/RocketMod/Rocket/blob/master/Farewell.md) for more information.
