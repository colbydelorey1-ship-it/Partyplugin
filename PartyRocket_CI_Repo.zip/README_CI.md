
# PartyPlugin + Rocket.Unturned CI Build

This repo lets you build **Rocket.Unturned.dll** and **PartyPlugin.dll** via GitHub Actions from your phone.

## One-time setup
1. Upload these two files from your Unturned server into `Rocket.Unturned-master/Rocket.Unturned/lib/` (same folder as Assembly-CSharp.dll):
   - `UnityEngine.dll` (from `Unturned/Unturned_Data/Managed/`)
   - `Assembly-CSharp-firstpass.dll` (from `Unturned/Unturned_Data/Managed/`)

I already placed the other Unturned DLLs I could get from your nupkg in that folder.

## How to use
1. Create a new GitHub repo (you can do this from the GitHub iOS app or mobile web).
2. Upload the **contents** of this zip to the repo (keep the folder structure).
3. Add the two DLLs above to `Rocket.Unturned-master/Rocket.Unturned/lib/`.
4. In GitHub, go to the **Actions** tab. The workflow **Build Rocket + PartyPlugin** will run.
5. When it finishes, download artifacts:
   - `RocketBuild`: contains `Rocket.Unturned.dll` (and its packages)
   - `PartyPluginBuild`: contains `PartyPlugin.dll`

## Deploy
- Copy `PartyPlugin.dll` to `Servers/<YourServer>/Rocket/Plugins/`
- Ensure Rocket module is installed/enabled on your server.
- Give players the `party.use` permission.
